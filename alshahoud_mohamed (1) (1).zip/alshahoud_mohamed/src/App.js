import React from 'react';

import ListeArticles from './composants/ListeArticles';
import FormArticles from './composants/Forms/FormArticles';

const ARTICLES = [
    {
      "id": "7f39cabd-cc8e-42c4-ad33-5a1565b4ccf6",
      "auteur": "Shelton Russo",
      "titre": "velit qui quis aute fugiat",
      "contenu": "adipisicing occaecat reprehenderit ut id eu occaecat aliquip ipsum fugiat excepteur magna labore et sint consequat qui ex excepteur voluptate mollit nulla non commodo duis ad culpa aliqua irure duis sit qui nulla Lorem laborum ullamco sint et magna adipisicing minim nulla aliquip nostrud duis laboris consectetur ex aliquip sint nostrud adipisicing deserunt fugiat excepteur ipsum consequat officia in quis sint dolore enim dolore dolor Lorem officia laborum enim voluptate ex eu enim anim nostrud in do deserunt ullamco ex amet ipsum culpa minim nulla nisi qui eiusmod duis laboris amet non cupidatat veniam exercitation deserunt exercitation non labore id",
      "date": "2022-03-14T19:21:08.811Z",
      "commentaires": [
        {
          "id": "b117a080-e992-4cac-a18c-3b60cc37018e",
          "auteur": "Freeman Byers",
          "contenu": "Lorem sint eiusmod voluptate adipisicing cillum esse minim nostrud eu",
          "date": "2022-05-29T18:58:02.073Z"
        },
        {
          "id": "17bb53b0-bd06-4f30-8a61-49f1077341eb",
          "auteur": "Galloway Powell",
          "contenu": "nisi minim aute sit enim ad aute voluptate eiusmod labore",
          "date": "2022-05-06T12:56:51.508Z"
        },
        {
          "id": "707cb021-3f50-4d53-bf69-eedf665f64fd",
          "auteur": "Cara Mcmillan",
          "contenu": "elit eu velit elit culpa officia dolore excepteur enim consectetur",
          "date": "2022-03-24T14:35:24.749Z"
        },
        {
          "id": "50acd199-1101-499d-a927-4b3ec53c38eb",
          "auteur": "Helga Beach",
          "contenu": "qui sit commodo sit irure laboris dolore aliqua dolore sunt",
          "date": "2022-04-03T00:45:05.925Z"
        }
      ]
    },
    {
      "id": "8b03a583-76c4-4644-9c3b-134042c921f5",
      "auteur": "Sally Burt",
      "titre": "irure nisi cillum consequat ad",
      "contenu": "quis ullamco sint aute deserunt dolore eiusmod laboris laboris pariatur adipisicing qui duis dolor exercitation non culpa aliquip ea ex consequat consectetur veniam dolore ut quis incididunt tempor cupidatat irure anim adipisicing labore adipisicing pariatur amet sit aliquip irure irure quis nisi reprehenderit excepteur esse anim culpa sint consequat id quis sint voluptate aliquip nulla nulla dolor nostrud consectetur amet sint voluptate occaecat deserunt voluptate excepteur anim ex officia duis dolore laboris consequat minim tempor cillum aliqua do aute ad voluptate irure Lorem velit adipisicing irure commodo et ipsum anim sint voluptate elit labore anim esse commodo fugiat quis duis",
      "date": "2022-03-28T22:42:03.573Z",
      "commentaires": [
        {
          "id": "0728f9c3-01eb-42d4-b9a8-62f916d5925c",
          "auteur": "Jolene Wiley",
          "contenu": "id nisi pariatur ex minim id ex esse et pariatur",
          "date": "2022-04-27T11:37:44.572Z"
        },
        {
          "id": "7be54ef6-42da-4eff-a970-6c3c9983f890",
          "auteur": "Eve Dale",
          "contenu": "ipsum ut amet pariatur pariatur ea aute elit magna exercitation",
          "date": "2022-06-09T18:08:21.856Z"
        },
        {
          "id": "e2383b08-8319-44c5-85e5-95221d953730",
          "auteur": "Flossie Lyons",
          "contenu": "ex esse quis cupidatat consectetur irure nulla Lorem non quis",
          "date": "2022-04-12T11:40:29.827Z"
        }
      ]
    },
    {
      "id": "48c4ffbd-c0be-495e-acf7-bceb257b09ae",
      "auteur": "Odonnell Salinas",
      "titre": "aliquip deserunt sint deserunt nisi",
      "contenu": "irure velit elit cupidatat qui ad magna pariatur voluptate commodo nisi quis irure mollit nisi nisi minim do laborum consequat culpa fugiat proident elit fugiat exercitation magna amet ea reprehenderit elit tempor eiusmod cillum ad cupidatat et et cillum magna ea ullamco commodo exercitation enim est ad ullamco duis culpa ad laborum velit adipisicing ea labore officia elit proident cillum dolore laborum ad nulla nostrud dolore anim velit eiusmod ut consectetur aliquip consectetur consequat qui sit duis dolor esse adipisicing nisi enim cupidatat duis non quis Lorem consequat nostrud consequat tempor fugiat ad sunt deserunt Lorem magna non commodo exercitation",
      "date": "2022-06-19T15:01:52.313Z",
      "commentaires": [
        {
          "id": "6651a4be-debc-40ea-9121-2d9861d5537f",
          "auteur": "Mcguire Graham",
          "contenu": "tempor sit adipisicing proident commodo excepteur sit culpa amet ex",
          "date": "2022-06-16T21:59:13.291Z"
        },
        {
          "id": "b3826159-aa46-460d-9a42-941e7edbb8c8",
          "auteur": "Clay Estrada",
          "contenu": "consequat magna nostrud ad voluptate cupidatat ea id sit minim",
          "date": "2022-06-17T13:03:21.754Z"
        }
      ]
    },
    {
      "id": "7fc31087-a73c-4544-af9d-4405c7834bfb",
      "auteur": "Amelia Contreras",
      "titre": "tempor ad labore tempor irure",
      "contenu": "et ea consectetur adipisicing id incididunt nostrud reprehenderit ea occaecat nisi cillum fugiat qui anim pariatur nostrud laboris amet non officia et aute laboris cillum magna nulla commodo ullamco tempor irure laborum sunt pariatur dolor Lorem reprehenderit aute voluptate id incididunt aliqua excepteur ex Lorem sunt ex labore elit est ipsum aliquip incididunt dolor et reprehenderit tempor commodo sunt laboris elit nisi labore do voluptate nulla anim dolor nostrud aliqua culpa ipsum incididunt non labore magna laborum et enim consequat nisi magna ut cupidatat cupidatat consequat aute proident mollit est consectetur excepteur eu amet sint fugiat quis commodo fugiat est",
      "date": "2022-03-02T16:35:47.015Z",
      "commentaires": [
        {
          "id": "db8928e1-8259-445f-baa3-2ac5112415e0",
          "auteur": "Cecile Dodson",
          "contenu": "irure consequat in Lorem qui excepteur non nostrud enim duis",
          "date": "2022-05-07T20:29:40.659Z"
        },
        {
          "id": "02d97a70-0290-4fc0-acd7-df32992abfad",
          "auteur": "Reva Reilly",
          "contenu": "amet dolore sint enim eu laboris consectetur incididunt nisi non",
          "date": "2022-06-10T00:37:09.275Z"
        }
      ]
    },
    {
      "id": "3f495d50-3bd8-452a-b720-ad4b67491664",
      "auteur": "Angeline Dejesus",
      "titre": "commodo aliqua non minim culpa",
      "contenu": "esse eu laboris nisi velit commodo deserunt sint reprehenderit proident sint labore ullamco cupidatat dolor cillum excepteur velit ullamco dolore nostrud proident laborum dolore amet officia tempor elit sunt nulla laborum velit ad Lorem pariatur laboris quis cupidatat laboris aliqua nostrud proident amet dolore duis deserunt culpa qui amet occaecat minim reprehenderit velit proident nisi dolore mollit aute anim exercitation proident eu aliquip amet est ex adipisicing non voluptate consequat nisi ut nostrud culpa fugiat commodo elit sit consectetur incididunt est consectetur labore mollit laborum ut veniam ullamco ea minim reprehenderit ad nisi labore incididunt officia duis irure officia adipisicing",
      "date": "2022-03-24T01:16:56.691Z",
      "commentaires": [
        {
          "id": "496b68ca-9e38-44a7-b792-729e6f436de7",
          "auteur": "Oneill Mccall",
          "contenu": "ipsum est sit fugiat do aliquip in consectetur ipsum cupidatat",
          "date": "2022-05-12T21:07:31.798Z"
        },
        {
          "id": "2b75c8e7-e03c-49c4-b695-e1b2f4eeadca",
          "auteur": "Gonzales Talley",
          "contenu": "labore et ipsum cupidatat sunt sit laboris qui nulla Lorem",
          "date": "2022-05-04T21:48:34.945Z"
        }
      ]
    },
    {
      "id": "5b19163c-8929-49d3-ae7f-2cd4d70b44ba",
      "auteur": "Campbell Hodge",
      "titre": "excepteur aute id officia laborum",
      "contenu": "proident sunt sint sint ut incididunt velit tempor irure officia consequat incididunt cillum adipisicing ea laboris consequat nisi deserunt commodo ullamco dolor pariatur in ullamco et adipisicing amet quis elit consectetur dolore mollit nisi do ut est dolor aute commodo consectetur culpa velit quis Lorem id qui veniam quis laboris nisi irure sit ullamco nisi commodo veniam magna incididunt officia aute ex amet officia in anim ut laborum occaecat amet adipisicing commodo ea nulla elit in est labore fugiat consequat cillum ipsum ut cupidatat mollit consectetur aliquip ex magna labore in voluptate occaecat sint sit velit duis cillum in sunt",
      "date": "2022-04-30T02:18:37.116Z",
      "commentaires": [
        {
          "id": "8c62a245-a349-47a2-a9af-2226210dcd6b",
          "auteur": "Marisa Reeves",
          "contenu": "occaecat officia pariatur nulla aliqua voluptate adipisicing duis ad consequat",
          "date": "2022-05-03T12:09:16.490Z"
        },
        {
          "id": "ecb3a7dc-145b-43af-b8e1-fc44585b01bd",
          "auteur": "Burris Munoz",
          "contenu": "amet consectetur nisi consequat do consequat eiusmod ex dolore cillum",
          "date": "2022-05-12T13:29:56.551Z"
        },
        {
          "id": "0363d741-40ce-4d68-b948-943c26886174",
          "auteur": "Katheryn Matthews",
          "contenu": "proident et officia fugiat amet consequat magna incididunt duis do",
          "date": "2022-05-22T09:09:09.354Z"
        }
      ]
    },
    {
      "id": "530d3ed4-7abe-4683-95fc-115269dc02b9",
      "auteur": "Ryan Sullivan",
      "titre": "voluptate fugiat ea laboris occaecat",
      "contenu": "occaecat culpa id incididunt fugiat duis enim eu ullamco esse cillum eu aliquip ea sint quis dolor proident id id culpa occaecat ea esse elit voluptate Lorem nulla deserunt id quis non reprehenderit proident tempor ut nulla aliqua do voluptate reprehenderit est eiusmod sint incididunt eu occaecat ipsum ea elit sint proident elit dolore ut sit id velit mollit pariatur eu aliquip ad minim ad adipisicing non in labore sit ipsum est laboris laboris adipisicing velit incididunt eu excepteur ad et dolore adipisicing ipsum labore pariatur nisi nisi deserunt excepteur velit consequat reprehenderit anim incididunt tempor elit aliquip esse incididunt",
      "date": "2022-06-07T12:58:21.539Z",
      "commentaires": [
        {
          "id": "05db42c5-df5f-471d-bd64-ab54cd3820b9",
          "auteur": "Misty Curtis",
          "contenu": "duis enim in fugiat reprehenderit aliquip ad reprehenderit adipisicing consequat",
          "date": "2022-06-12T18:20:03.712Z"
        },
        {
          "id": "0bedb737-761f-4111-b6c0-303070506da0",
          "auteur": "Hudson Knight",
          "contenu": "ad minim et commodo ipsum ipsum dolore officia magna nisi",
          "date": "2022-06-09T23:00:42.534Z"
        },
        {
          "id": "538a8ab6-3363-4797-8586-3e1f9f952399",
          "auteur": "Barrera Cross",
          "contenu": "consectetur mollit dolore aliquip exercitation est non fugiat aute do",
          "date": "2022-06-14T23:05:43.810Z"
        }
      ]
    },
    {
      "id": "9883565a-5d2f-42a2-a795-11dcfc40fc2d",
      "auteur": "Garner White",
      "titre": "proident ipsum consequat consequat esse",
      "contenu": "commodo cillum elit irure consequat laborum consectetur duis laborum in deserunt ea commodo reprehenderit magna incididunt minim ea in cupidatat consectetur amet proident officia qui consequat in esse id esse excepteur sit elit ea reprehenderit ex in aliquip cillum Lorem labore aute incididunt non laborum ea anim incididunt exercitation dolor voluptate consectetur consequat cillum aute ea mollit pariatur pariatur incididunt commodo ullamco fugiat labore velit ad Lorem ullamco ullamco ipsum minim deserunt Lorem officia dolor ipsum irure ea elit elit non in eu ipsum aliqua cupidatat aliqua amet ipsum amet Lorem dolore laborum ut adipisicing Lorem ipsum aliqua amet duis",
      "date": "2022-05-30T21:36:03.978Z",
      "commentaires": [
        {
          "id": "d49322c0-239d-4257-9867-bef62fd47520",
          "auteur": "Lauri Owen",
          "contenu": "consectetur mollit consequat voluptate voluptate duis magna proident anim officia",
          "date": "2022-06-14T08:39:28.848Z"
        },
        {
          "id": "917efc16-845f-4a24-a891-a6c9f61bfce6",
          "auteur": "Leslie Skinner",
          "contenu": "Lorem labore dolor esse mollit pariatur eu fugiat non anim",
          "date": "2022-06-10T06:16:02.421Z"
        },
        {
          "id": "0ff7723d-5828-4139-9ca2-85196b12d41b",
          "auteur": "Claudette Roman",
          "contenu": "consequat cupidatat enim minim nisi pariatur dolor eiusmod labore occaecat",
          "date": "2022-06-08T18:00:04.576Z"
        }
      ]
    },
    {
      "id": "cd76446e-2ce0-457b-b7e5-edfd0ef56857",
      "auteur": "Monique Crawford",
      "titre": "adipisicing tempor ut esse aliqua",
      "contenu": "Lorem duis nostrud do aliqua occaecat consectetur exercitation ex aliquip irure nulla et elit Lorem deserunt ad Lorem laboris sit aliquip culpa duis laborum adipisicing exercitation aliquip culpa dolore et enim consequat cupidatat do adipisicing eu Lorem aute ipsum ut velit consequat eiusmod qui non minim Lorem irure velit aliqua elit sunt exercitation proident qui in anim aliquip anim culpa duis adipisicing labore eu quis est anim est reprehenderit sunt officia non in sunt laboris amet duis deserunt cillum amet dolor reprehenderit reprehenderit cillum ipsum et est occaecat voluptate ipsum amet ullamco occaecat irure tempor incididunt eu irure enim enim",
      "date": "2022-03-28T11:27:12.393Z",
      "commentaires": [
        {
          "id": "ab9463fb-bb53-4395-8c5c-61c4717a6eaa",
          "auteur": "Darcy Sharp",
          "contenu": "velit eiusmod nisi aute pariatur amet cillum culpa sint consectetur",
          "date": "2022-05-07T02:40:20.833Z"
        }
      ]
    },
    {
      "id": "6c6623a9-1db1-48bd-abc6-199624c722b1",
      "auteur": "Mcknight Pate",
      "titre": "labore elit Lorem labore voluptate",
      "contenu": "irure ex est eu duis amet incididunt excepteur irure adipisicing est quis velit ullamco nulla laborum nulla proident non officia culpa amet aliquip tempor ipsum eiusmod anim elit do enim aliquip laborum pariatur dolor do labore veniam commodo magna sit adipisicing dolor laborum ipsum nulla dolor adipisicing occaecat ut eu elit exercitation labore amet incididunt ad do reprehenderit ea ullamco eiusmod sint duis esse veniam commodo in cupidatat elit eiusmod elit incididunt fugiat qui aute eu incididunt do exercitation sit quis eiusmod ex consectetur ipsum ad non laborum elit in veniam fugiat consectetur ad ut aute sit minim sit do",
      "date": "2022-05-26T01:04:51.757Z",
      "commentaires": [
        {
          "id": "c7d27d2d-4161-4740-b11b-12e2f3fabd4d",
          "auteur": "Inez Cummings",
          "contenu": "minim incididunt reprehenderit veniam et non ipsum proident exercitation officia",
          "date": "2022-05-27T20:40:24.664Z"
        },
        {
          "id": "3a5a6a66-d0d6-4f85-bfe6-6f855f1693b2",
          "auteur": "Frazier Rose",
          "contenu": "cillum Lorem est do eu fugiat labore aliqua sit laboris",
          "date": "2022-06-13T06:34:29.294Z"
        },
        {
          "id": "89270a68-49a5-4ba0-bc43-f0582ea13e59",
          "auteur": "Lloyd Buckner",
          "contenu": "in tempor adipisicing excepteur incididunt cillum non do tempor et",
          "date": "2022-06-08T13:36:35.428Z"
        }
      ]
    }
  ];

  class App extends React.Component{ 

    render(){
        return(
            <div style={{padding:"15px"}}>
               <h1>Examen 2022</h1>
               <FormArticles />
               <ListeArticles articles={ARTICLES}/>
            </div>
        )
    }
}
  export default App;

