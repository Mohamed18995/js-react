import React from "react";
import Article from "./Article";

class ListeArticles extends React.Component {
  render() {
    return (
      <div style={{display: "grid", gridTemplateColumns: "1fr 1fr 1fr"}}>
        {this.props.articles.map((article, index) => <Article {...article} key={index}/>)}
      </div>
    )
  }
}

export default ListeArticles;