import React from "react";

class FormArticles extends React.Component{

 render(){
    return(
        <div style={{border: "1px solid black", margin:"0 10px"}}>
            <button style={{backgroundColor:"green", color:"white", fontSize:"14px", margin:"10px"}}>Formulaire de recherche</button>
        </div>
        )
 }   
}

export default FormArticles;