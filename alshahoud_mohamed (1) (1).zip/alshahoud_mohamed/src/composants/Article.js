import React from "react";

class Article extends React.Component {
  constructor(props){
    super(props);
    this.state={
      affichage:false
    };
    this.handleAffichageChange = this.handleAffichageChange.bind(this);

  }
  handleAffichageChange(){
    this.setState({
      affichage:!this.state.affichage
    })
 }

  render() {
    return (
        <div style={{border:"1px solid black", borderRadius:"3px",margin:"10px", marginBottom:"15px", backgroundColor:'grey'}}>
          <div style={{marginBottom:"15px", backgroundColor:'white', padding:"10px"}}>
            <h2 style={{fontWeight:"500", fontSize:'13px'}}>{this.props.titre}</h2>
            <h3 style={{fontSize:"10px"}}>Ecrit par {this.props.auteur} le {this.props.date}</h3>
            <p style={{fontSize:"10px"}}>{this.props.contenu}</p>
          </div>
          <div>
            <p style={{fontSize:"10px", paddingLeft:"10px"}} onClick={this.handleAffichageChange}>il y a {this.props.commentaires.length} commentaires</p>

            <div style={{display: this.state.affichage ? "block" : "none"}}>
              {this.props.commentaires.map(cmt => (
                <div key={cmt.id} style={{border:'1px solid black', paddingBottom:'1rem', borderRadius:'3px', padding:'0.3rem', margin:'1rem', backgroundColor:'white'}}>
                  <h3 style={{fontSize:"10px"}}>Ecrit par {cmt.auteur} le {cmt.date}</h3>
                  <p style={{fontSize:"10px"}}>{cmt.contenu}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
    )
  }
}

export default Article;